<table class="table-layout">
    <thead>    
        <tr>
            <th>Opportunity name</th>
            <th>Sales agent</th>
            <th>Sales region</th>
            <th>Sales category</th>
            <th>Forecast amount</th>
            <th>Probability of sale</th>
        </tr>
    </thead>
    <tbody>
    <?php include('adt-item.php');?>
    </tbody>
</table>